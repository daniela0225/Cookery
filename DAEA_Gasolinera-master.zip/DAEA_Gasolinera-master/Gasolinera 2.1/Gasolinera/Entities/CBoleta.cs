﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class CBoleta
    {
        public int codigo { get; set; }
        public int venta { get; set; }
        public string dni { get; set; }
        public float total { get; set; }
    }
}
