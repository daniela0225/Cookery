﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class CCliente
    {
        public int codigo { get; set; }
        public string tipo_doc { get; set; }
        public string documento { get; set; }
        public string nom_ape { get; set; }
        public string direccion { get; set; }
    }
}
