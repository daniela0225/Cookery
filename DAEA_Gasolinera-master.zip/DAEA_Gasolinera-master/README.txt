﻿
Gasolinera
=========================================================================
Entregable III

Modificaciones en:

DAL:
- UsuarioDAL

BLL:
- UsuarioBLL
- Encriptador
- AccessMiddleware

WebInterface:
- Todos los controladores


=========================================================================
Entregable II

Interfaces
	Juan Pino:
		- Ventas
		- Usuarios
	Gabtim León:
		- Facturas
		
	Bryan Huayta:
		- Contribuyente
	Joshua Miranda:
		- Producto
	Renzo Dávila:
		- Cliente
		- Boleta
Acceso a las vistas:
	http://localhost:puerto/Venta
	http://localhost:puerto/Usuario
	http://localhost:puerto/Contribuyente
	ETC.